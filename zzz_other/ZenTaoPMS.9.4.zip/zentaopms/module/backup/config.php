<?php
$config->backup = new stdclass();
$config->backup->holdDays = 14;
