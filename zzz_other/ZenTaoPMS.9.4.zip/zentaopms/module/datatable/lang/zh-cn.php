<?php
$lang->datatable = new stdclass();
$lang->datatable->common = '数据表格';
$lang->datatable->width  = '宽度';
$lang->datatable->show   = '显示';
$lang->datatable->hide   = '隐藏';

$lang->datatable->custom            = '自定义列';
$lang->datatable->customTip         = '勾选需要显示的列';
$lang->datatable->switchToTable     = '切换到简单表格';
$lang->datatable->switchToDatatable = '切换到高级表格';
$lang->datatable->required          = '必选';

$lang->datatable->branch   = '分支';
$lang->datatable->platform = '平台';

$lang->datatable->showModule             = '列表页是否显示模块名';
$lang->datatable->showModuleList[]       = '不显示';
$lang->datatable->showModuleList['base'] = '只显示一级模块';
$lang->datatable->showModuleList['end']  = '只显示最后一级模块';
